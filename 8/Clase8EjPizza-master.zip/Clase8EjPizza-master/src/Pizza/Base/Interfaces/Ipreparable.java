package Pizza.Base.Interfaces;

public interface Ipreparable {
    void prepare();
}
